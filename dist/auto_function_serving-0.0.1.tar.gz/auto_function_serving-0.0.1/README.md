# auto-function-serving
A python package to offload a function call to an http server running on localhost automatically using a decorator. Compatible with multiprocessing, pickle and flask.
